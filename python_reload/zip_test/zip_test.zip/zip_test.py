
def func():
    return 2
